﻿using NUnit.Framework;
using MockExamConsole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockExamConsole.Tests
{
    [TestFixture()]
    public class OwnnerTests
    {
        [Test()]
        public void Adress()
        {

        }
    }
}